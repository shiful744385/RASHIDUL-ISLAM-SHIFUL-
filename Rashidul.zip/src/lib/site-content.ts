export type Work = {
  slug: string;
  index: string;
  client: string;
  title: string;
  year: string;
  sector: string;
  summary: string;
  services: string[];
  outcome: string;
  stats: { label: string; value: string }[];
  brief: string;
  approach: string[];
  body: string[];
};

export type Article = {
  slug: string;
  title: string;
  date: string;
  author: string;
  role: string;
  minutes: number;
  kicker: string;
  dek: string;
  paragraphs: string[];
};

export type Repo = {
  name: string;
  description: string;
  language: string;
  stars: string;
  license: string;
  updated: string;
};

export type Role = {
  id: string;
  title: string;
  team: string;
  location: string;
  type: string;
  summary: string;
  points: string[];
};

export const stack = [
  "TypeScript",
  "React",
  "Node.js",
  "Python",
  "Go",
  "PostgreSQL",
  "Rust",
  "APIs",
];

export const services = [
  {
    index: "01",
    title: "Web applications",
    summary:
      "Interfaces and the code behind them. I build products people use all day, in TypeScript and React, with states that are specified — not only drawn.",
    deliverables: [
      "Application structure and routing",
      "UI that stays dense when the work is dense",
      "Forms, empty states, and errors",
      "A build your team can keep shipping",
    ],
  },
  {
    index: "02",
    title: "APIs & backends",
    summary:
      "Services with an error model, a schema, and a way to know they are still up. Node, Python, or Go — picked for the problem, not for fashion.",
    deliverables: [
      "HTTP or RPC API design",
      "Postgres schema and migrations",
      "Auth boundaries and audit where it matters",
      "Tests on the paths that actually fail",
    ],
  },
  {
    index: "03",
    title: "Tools & libraries",
    summary:
      "The small programs teams rewrite every quarter. CLIs, internal kits, and libraries with a readme a stranger can follow.",
    deliverables: [
      "CLI or library with a real interface",
      "Docs and a license",
      "Fixtures from the messy case",
      "A maintainer note, not a drive-by repo",
    ],
  },
  {
    index: "04",
    title: "Code care",
    summary:
      "After the first release I stay. Performance, dependencies, and the bugs that only show up once real data arrives.",
    deliverables: [
      "A short written diagnosis",
      "Fixes in your repository",
      "A performance or reliability budget",
      "Notes so the next person is not guessing",
    ],
  },
];

export const method = [
  {
    index: "01",
    title: "Read",
    text: "I read the code and the constraint before I open an editor. If the problem cannot be said in a page, it is not ready to be programmed.",
  },
  {
    index: "02",
    title: "Model",
    text: "Data, errors, and the one path a user repeats. The model is the design. Screens follow it.",
  },
  {
    index: "03",
    title: "Code",
    text: "Small slices, in the repository you already have. Types at the boundary. No private framework you will have to hire me forever to touch.",
  },
  {
    index: "04",
    title: "Ship",
    text: "A weekly build someone can click. If it is not in production or in a reviewer’s hands, it is not progress.",
  },
  {
    index: "05",
    title: "Leave it clear",
    text: "The job ends when another programmer can change it. Decision notes, tests, and a runbook are part of the code.",
  },
];

export const principles = [
  {
    title: "Name the type at the boundary",
    body: "Inside a function I will be flexible. At the edge — an API, a form, a file, a queue — the shape is explicit. Untyped JSON that “we all understand” is how a Tuesday bug is born. I would rather argue about a schema on day two than debug a silent null in month four.",
  },
  {
    title: "Write the failure",
    body: "Happy paths are the easy half. Every meaningful function says what it does when the network drops, the row is missing, or the user sends the long name. The message a person reads is part of the program, not a string someone adds after launch.",
  },
  {
    title: "Prefer boring code",
    body: "A straightforward module that a new teammate can read beats a clever abstraction that only I remember. I reach for a library when it deletes real work, and I leave it out when it deletes clarity. Programming is a reading problem as much as a writing one.",
  },
  {
    title: "One repository, one truth",
    body: "Specs that live only in a chat thread rot. The code, the migration, and a short decision note are the record. If a behaviour matters, it has a test or it is written next to the function that implements it.",
  },
  {
    title: "Ship a slice, not a platform",
    body: "I do not start by building a framework for the framework. The first code is the path the user actually takes, on real-shaped data. Generalise the second time you feel the pain, not the first time you imagine it.",
  },
  {
    title: "Open what I repeat",
    body: "A helper that has survived three projects becomes a public repository with docs and a license. Client business logic stays private. Scaffolding does not.",
  },
  {
    title: "Measure the slow line",
    body: "I do not add a dashboard of fourteen charts. I time the request, the query, or the click that people wait on, and I keep that number honest. Optimising a function nobody calls is not engineering.",
  },
  {
    title: "Leave the next programmer a map",
    body: "Comments that narrate the syntax are noise. Comments that say why a weird branch exists are the job. So are names. If I am the only one who can change the file, I have not finished programming it.",
  },
];

export const works: Work[] = [
  {
    slug: "ledgerkit",
    index: "01",
    client: "Library · TypeScript",
    title: "An append-only ledger for product events",
    year: "2026",
    sector: "Libraries",
    summary: "A small TypeScript library for recording what happened in a product, with an export a finance teammate can open.",
    services: ["Library design", "TypeScript", "Tests"],
    outcome: "Three products stopped inventing their own event table.",
    stats: [
      { label: "Language", value: "TypeScript" },
      { label: "Public", value: "Yes" },
      { label: "Call sites replaced", value: "3" },
    ],
    brief: "Every codebase I joined had a slightly different ‘events’ table and no agreement about updates. I wrote the one I was copying by hand.",
    approach: [
      "Append-only on purpose. Corrections are new events.",
      "A query layer small enough to read in an afternoon.",
      "CSV export that does not require the library to open.",
    ],
    body: [
      "The first version was a module inside a client repo. It grew a second copy, then a third, each with a bug the others had already fixed. That is the moment to extract a library, not the moment to design a platform.",
      "The API is small: append, read by subject, export. There is no plugin system. Types carry the event name and the payload, so a typo fails the build instead of the report.",
      "I tested the awkward cases — duplicate ids, a payload that grew a field, a reader on an older version. Those tests are the documentation I trust.",
      "It is public under Apache-2.0. If you use it and it fails you, the issues list is the door. I answer as the maintainer, not as a brand.",
    ],
  },
  {
    slug: "formidle",
    index: "02",
    client: "Library · TypeScript",
    title: "Forms as a state machine",
    year: "2026",
    sector: "Web",
    summary: "Multi-step forms that save, resume, and record why a step was skipped. Built because form bugs were eating review time.",
    services: ["TypeScript", "React", "State"],
    outcome: "A clinic intake and a permit form both shipped on the same machine.",
    stats: [
      { label: "Steps modelled", value: "Explicit" },
      { label: "Resume", value: "Yes" },
      { label: "Hidden state", value: "None" },
    ],
    brief: "Long forms were being built as a pile of booleans. I wanted one object that says where the person is, and why.",
    approach: [
      "Each step is a state with enter, exit, and skip reasons.",
      "Progress persists without a custom backend ritual.",
      "The UI is a consumer. The machine does not know about CSS.",
    ],
    body: [
      "The bugs were always the same: back-button amnesia, a required field that was not required on Tuesdays, a submit that fired twice. None of that is a styling problem.",
      "Formidle is the state machine I wanted to import. The React binding is thin. You can drive it from a test without rendering a component.",
      "Skip reasons are data. If a clinician or a clerk jumps ahead, the record says so. That one field saved more arguments than the animation ever would.",
      "I have used it on two very different products. The third time I need a multi-step form, I will not start from a blank useState.",
    ],
  },
  {
    slug: "nightwatch",
    index: "03",
    client: "CLI · Go",
    title: "A release checklist that fails the build",
    year: "2025",
    sector: "Tools",
    summary: "A Go command that refuses to tag a release when the notes, the owner, or the flag are missing.",
    services: ["Go", "CLI", "CI"],
    outcome: "Releases stopped depending on someone remembering the wiki page.",
    stats: [
      { label: "Language", value: "Go" },
      { label: "Checks", value: "Declarative" },
      { label: "Wiki pages", value: "Retired" },
    ],
    brief: "The checklist was real. It lived in a document nobody opened on Friday afternoon. I moved it into the pipeline.",
    approach: [
      "A YAML file in the repo is the checklist.",
      "Missing fields are a non-zero exit, not a warning.",
      "The output is a paragraph a human can paste into the tag.",
    ],
    body: [
      "I have watched careful teams ship the wrong flag because the reminder was a heading in Notion. Reminders are not programs. Exit codes are.",
      "Nightwatch reads a small spec: who owns the release, where the notes are, which config must have changed. It does not deploy. It only tells the truth before you do.",
      "Go was the right tool: one binary, no runtime to install on the runner, fast enough that nobody disables it for being slow.",
      "The interesting design choice was tone. The failure text says what to fix, in order, without a lecture. Programmers ignore lectures. They follow the next command.",
    ],
  },
  {
    slug: "paperdiff",
    index: "04",
    client: "Library · Rust",
    title: "Diffs that respect sentences",
    year: "2026",
    sector: "Libraries",
    summary: "A Rust library for prose diffs. Built for editors and clinicians comparing a paragraph, not for git.",
    services: ["Rust", "Text", "API"],
    outcome: "Reviewers stopped pasting essays into a code diff and guessing.",
    stats: [
      { label: "Language", value: "Rust" },
      { label: "Unit", value: "Sentence" },
      { label: "Bindings", value: "WASM-ready" },
    ],
    brief: "Line diffs tear sentences in half. I needed a diff a person reading prose could trust.",
    approach: [
      "Split on sentences, then align.",
      "Keep a plain text API. No editor required.",
      "Rust for the core, so it can sit behind more than one language later.",
    ],
    body: [
      "The first consumer was an editorial desk. The second was a clinic that needed to see what changed in a note. Same algorithm, different nouns.",
      "I did not try to solve every natural-language problem. Punctuation, quotes, and a stable alignment were enough to be useful. A perfect linguistic model was not the job.",
      "The Rust core is small and tested against a folder of ugly paragraphs: lists, names with periods, a sentence that is only a number.",
      "Programming this well meant resisting features. No themes. No accounts. A function from two strings to a list of changes.",
    ],
  },
  {
    slug: "quay-board",
    index: "05",
    client: "Product · TypeScript",
    title: "A live board for yard moves",
    year: "2025",
    sector: "Web",
    summary: "A web app on top of an equipment feed. Planners see exceptions. The calm hour stays quiet.",
    services: ["React", "API", "Postgres"],
    outcome: "The side whiteboard stopped being the system of record.",
    stats: [
      { label: "Stack", value: "React + Node" },
      { label: "Data", value: "Live feed" },
      { label: "Default UI", value: "Quiet" },
    ],
    brief: "Operations had events and a radio. They did not have a picture that admitted when the feed was stale.",
    approach: [
      "Integrate the feed before decorating the screen.",
      "Stale data is labelled in place.",
      "Exceptions interrupt. Everything else does not.",
    ],
    body: [
      "I started in the event log, not in Figma. If the picture is not fed by something true, it is a poster. The first week was parsing, not pixels.",
      "The interface is dense because the users are experts. Keyboard paths, contrast, and a status that does not lie were the design. Animation was not.",
      "Postgres holds the projection. The API is boring on purpose. The React app is a client of that API, so the same data can be checked without a browser.",
      "When the radio stayed on, it was for exceptions the software should not pretend to settle. That boundary was a coding decision and a product decision at once.",
    ],
  },
  {
    slug: "permit-status",
    index: "06",
    client: "Product · TypeScript",
    title: "One status for a city permit",
    year: "2024",
    sector: "APIs",
    summary: "A single application record and an API that tells a resident who has the file, in language they can act on.",
    services: ["API design", "Postgres", "Web"],
    outcome: "Seventeen forms became one record with a shared status.",
    stats: [
      { label: "Forms", value: "17 → 1" },
      { label: "Source of truth", value: "One row" },
      { label: "Departments", value: "Routed inside" },
    ],
    brief: "The resident was the integration layer between three portals. I replaced that with one schema.",
    approach: [
      "Model the legal state, not the org chart.",
      "A case cannot look in progress in two departments.",
      "Missing information is asked once, early, in plain words.",
    ],
    body: [
      "The programming problem was the state machine of a permit, not the colour of the button. Each transition has an owner and a reason. Illegal transitions do not have a UI.",
      "The public API returns a short status: what you asked, what is missing, who has it, what happens next. Internal routing stays internal.",
      "I wrote the copy in the same pull request as the handler. ‘Something went wrong’ was rejected in review, including by me.",
      "Cycle time moved because the data model stopped hiding the wait. The code made the wait visible. People did the rest.",
    ],
  },
];

export const articles: Article[] = [
  {
    slug: "types-at-the-boundary",
    title: "Types at the boundary",
    date: "4 March 2026",
    author: "JP Rashidul",
    role: "Programmer",
    minutes: 7,
    kicker: "Coding",
    dek: "Where I insist on a schema, and where I stop pretending a type system can save a muddy problem.",
    paragraphs: [
      "I do not annotate every local variable for sport. I do insist on a type where data crosses a line: an HTTP body, a database row, a file, a message from another service. That is where bugs become other people’s bugs.",
      "A TypeScript interface that mirrors a hopeful guess is not a schema. If the payload is JSON from outside, I parse it. Zod or a hand-written decoder, I do not mind. I mind the cast.",
      "Inside a function, once the boundary has spoken, I let the code be ordinary. A clever generic that exists to avoid one interface is a cost I rarely want to pay. Programming is maintenance.",
      "The same rule in Python: a dataclass or a typed dict at the edge, and tests that feed the ugly payload. In Go, the struct is the conversation. The language changes. The boundary does not.",
      "When a product person asks for a field ‘that might be anything’, I write down the three shapes it actually is. Anything-types are how a codebase loses the plot. The plot is the job.",
      "If you hire me, you will see this in the first pull request. I would rather slow the first endpoint than debug the tenth.",
    ],
  },
  {
    slug: "shipping-without-theatre",
    title: "Shipping without theatre",
    date: "12 January 2026",
    author: "JP Rashidul",
    role: "Programmer",
    minutes: 6,
    kicker: "Practice",
    dek: "A status update is a sentence about the code, not a performance about being busy.",
    paragraphs: [
      "Most updates list files touched. They do not say whether the behaviour is closer to true. I send four lines: what runs now, what I learned that changes the plan, what is blocked, and what I need from you.",
      "If a line is empty I write ‘nothing’. Inventing motion is how a project looks healthy while the risky branch sits untouched.",
      "The blocked line is the useful one. A risk said in week two is a planning problem. The same risk said after the demo is a broken promise, even if every ticket was green.",
      "I will draw a chart if your process requires the artefact. I will not let the chart replace the sentence. A green box has never told me whether the migration is safe.",
      "This is not less communication. It is communication that can be wrong in a useful way. If the note could have been sent without reading the diff, it is cover.",
      "The weeks that follow this rule are quieter. The code is not. Quiet is what you want from the process. The program can be loud when something is actually wrong.",
    ],
  },
  {
    slug: "the-spec-is-the-code",
    title: "The spec is the code",
    date: "2 November 2025",
    author: "JP Rashidul",
    role: "Programmer",
    minutes: 8,
    kicker: "Practice",
    dek: "A picture of a screen is not a specification. Behaviour, words, and errors are.",
    paragraphs: [
      "I still look at designs. I do not pretend a frame is the program. A screen without the empty state, the error, and the long name is a poster. Posters do not survive a real record.",
      "When I take a build, the spec I write is short. For each surface: what the person is trying to do, what the system does in each state, the exact words, and what is out of scope. If I cannot code the sentence, the sentence is wrong.",
      "Content is part of the interface. ‘Something went wrong’ is not a specification. The useful version says what failed, whether the work is safe, and the one next action. I put that string in the same change as the handler.",
      "I push back when a screenshot becomes a contract for edge cases nobody has discussed. Direction is welcome. Accidental scope is how programming estimates die.",
      "The test I use later is dull. Can another programmer change the behaviour without a tour of my memory? If the answer is no, I did not finish. I only typed.",
      "This is the standard on my own repositories too. A public tool with no description of failure is not finished, however green the tests that only pass the happy path.",
    ],
  },
  {
    slug: "what-i-open-source",
    title: "What I will and will not open-source",
    date: "9 September 2025",
    author: "JP Rashidul",
    role: "Programmer",
    minutes: 6,
    kicker: "Open source",
    dek: "Client problems stay private. Tools I have rebuilt three times do not.",
    paragraphs: [
      "I keep a small set of public tools. They are not a marketing plan. They are the pieces I was tired of rewriting at the start of every job, sanded until someone else could use them without a call.",
      "I do not publish a client’s domain. A permit workflow, a yard board, a private schema — those stay in their org. The scaffolding underneath sometimes does not.",
      "A repository earns a release when it has survived three uses, has my name on it as maintainer, and has docs a stranger can follow on a Sunday. Otherwise it stays private. A public repo with no steward is litter.",
      "Licenses are chosen on purpose. Libraries I want people to embed are permissive. I say which in the readme, on the first screen, not in a thread.",
      "Issues get an answer, even when the answer is no. I do not promise a roadmap that belongs to a client’s calendar. The maintenance note in the repo is the promise, and I keep it.",
      "If something of mine fails you, write to the address in the repository. It reaches me. It is not a community alias pointed at nobody.",
    ],
  },
];

export const repos: Repo[] = [
  {
    name: "ledgerkit",
    description: "Append-only ledgers for product events, with a small query layer and an export a spreadsheet can open.",
    language: "TypeScript",
    stars: "1,284",
    license: "Apache-2.0",
    updated: "Mar 2026",
  },
  {
    name: "formidle",
    description: "Multi-step forms as an explicit state machine. Saves, resumes, and records why a step was skipped.",
    language: "TypeScript",
    stars: "986",
    license: "Apache-2.0",
    updated: "Feb 2026",
  },
  {
    name: "paperdiff",
    description: "Prose diffs that respect sentences. For editors and notes, not for pull-request line noise.",
    language: "Rust",
    stars: "742",
    license: "MIT",
    updated: "Jan 2026",
  },
  {
    name: "kiln-ui",
    description: "A compact React set for dense tools. No marketing-page styles. States included.",
    language: "TypeScript",
    stars: "1,640",
    license: "MIT",
    updated: "Mar 2026",
  },
  {
    name: "nightwatch",
    description: "A release checklist in Go. Fails the build when the notes, the flag, or the owner are missing.",
    language: "Go",
    stars: "403",
    license: "Apache-2.0",
    updated: "Nov 2025",
  },
  {
    name: "routebrush",
    description: "Constraint checks for plans and schedules. Rules written down, then encoded.",
    language: "Rust",
    stars: "518",
    license: "MIT",
    updated: "Dec 2025",
  },
  {
    name: "census-py",
    description: "Offline capture for field surveys, with conflict marks and a plain export.",
    language: "Python",
    stars: "277",
    license: "Apache-2.0",
    updated: "Oct 2025",
  },
  {
    name: "adr-lint",
    description: "Lints decision records so ‘we will write it later’ does not survive code review.",
    language: "Go",
    stars: "351",
    license: "MIT",
    updated: "Aug 2025",
  },
];

export const roles: Role[] = [
  {
    id: "product-build",
    title: "Product build",
    team: "Web + API",
    location: "Remote · Dhaka",
    type: "A few months",
    summary: "I join your repository and ship a slice of the product: interface, API, and the data underneath. Weekly code, not a slide.",
    points: [
      "TypeScript, React, and a boring API.",
      "You keep the repository and the IP.",
      "A Friday note that can say ‘blocked’.",
    ],
  },
  {
    id: "backend",
    title: "API and data",
    team: "Backend",
    location: "Remote · Dhaka",
    type: "Scoped",
    summary: "Schema, endpoints, and the failure cases. Node, Python, or Go, chosen because it fits the system you already run.",
    points: [
      "Postgres when it is the right store.",
      "Parsers at the boundary, not casts.",
      "Tests for the payload you are afraid of.",
    ],
  },
  {
    id: "tooling",
    title: "Internal tool or CLI",
    team: "Tools",
    location: "Remote · Dhaka",
    type: "A few weeks",
    summary: "The script everyone rewrites. I turn it into a small program with docs, then I leave it in your hands.",
    points: [
      "One binary or one library.",
      "A readme a new teammate can follow.",
      "No framework you must hire me to touch.",
    ],
  },
  {
    id: "rescue",
    title: "Code rescue",
    team: "Care",
    location: "Remote · Dhaka",
    type: "Short",
    summary: "Something shipped and now it hurts. I read it, write the diagnosis, and fix the part that is actually slow or wrong.",
    points: [
      "A written diagnosis before a large rewrite.",
      "Fixes in your repo, reviewed by your team.",
      "I will say if a rewrite is the wrong spend.",
    ],
  },
];

export const faqs = [
  {
    q: "What kind of programming do you take?",
    a: "Web applications, APIs, and developer tools. TypeScript and React for the product surface. Node, Python, or Go for services and CLIs. I am not the right person for a native mobile rewrite or a machine-learning research project.",
  },
  {
    q: "Do you only advise, or do you code?",
    a: "I code. Advice that never becomes a pull request is a document. Most work is implementation in your repository. A short diagnosis, clearly labelled, is the exception.",
  },
  {
    q: "Can you work inside our team?",
    a: "Yes. The useful shape is one repository, one review, one weekly note. I do not run a parallel codebase and reappear at the end.",
  },
  {
    q: "Where are you based?",
    a: "Dhaka. I work remotely, with overlap for review. Workshops in person only when the problem is on a floor I need to see.",
  },
  {
    q: "Who owns the code?",
    a: "You do. It lands in your org. My public libraries stay under their licenses. Your domain model does not become my next repository.",
  },
  {
    q: "How do we start?",
    a: "A note with the constraint is enough. No deck. If I am the wrong programmer I will say so. This page is a portfolio demo, so the form does not email me — use the address once this is your real site.",
  },
];

export function getWork(slug: string) {
  return works.find((item) => item.slug === slug);
}

export function getArticle(slug: string) {
  return articles.find((item) => item.slug === slug);
}

export const sectors = ["All", ...Array.from(new Set(works.map((item) => item.sector)))];

export const languages = ["All", ...Array.from(new Set(repos.map((item) => item.language)))];
