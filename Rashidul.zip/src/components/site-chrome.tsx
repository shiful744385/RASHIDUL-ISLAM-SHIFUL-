import { useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { buttonStyles } from "@/components/ui/button";
import { cn } from "@/lib/cn";

const NAV = [
  { to: "/work", label: "Code" },
  { to: "/services", label: "Services" },
  { to: "/about", label: "About" },
  { to: "/journal", label: "Notes" },
  { to: "/open-source", label: "Open source" },
  { to: "/careers", label: "Hire" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-canvas/95 backdrop-blur-sm">
      <div className="border-b border-line">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-2 md:px-8">
          <p className="text-xs tracking-wide text-muted">Open for programming work — web, APIs, and tools.</p>
          <Link to="/contact" className="shrink-0 text-xs font-medium text-accent underline-offset-4 hover:underline">
            Hire JP
          </Link>
        </div>
      </div>
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5 md:px-8">
        <Link to="/" className="inline-flex items-center gap-2.5 text-ink">
          <span className="inline-block size-3.5 bg-accent" aria-hidden />
          <span className="font-serif text-lg leading-none tracking-tight sm:text-xl">JP Rashidul</span>
        </Link>
        <nav className="hidden items-center gap-6 lg:flex" aria-label="Primary">
          {NAV.map((item) => {
            const active = pathname === item.to || pathname.startsWith(`${item.to}/`);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "text-sm text-muted hover:text-ink",
                  active && "text-ink underline decoration-accent decoration-2 underline-offset-8",
                )}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/contact" className={cn(buttonStyles(), "hidden sm:inline-flex")}>
            Contact
          </Link>
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center border border-line lg:hidden"
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((value) => !value)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>
      {open ? (
        <nav className="border-t border-line bg-canvas px-5 py-4 lg:hidden" aria-label="Mobile">
          <ul className="flex flex-col">
            {NAV.map((item) => (
              <li key={item.to} className="border-b border-line">
                <Link
                  to={item.to}
                  className="flex min-h-12 items-center font-serif text-2xl"
                  onClick={() => setOpen(false)}
                >
                  {item.label}
                </Link>
              </li>
            ))}
            <li className="pt-4">
              <Link to="/contact" className={buttonStyles({ variant: "secondary" })} onClick={() => setOpen(false)}>
                Contact
              </Link>
            </li>
          </ul>
        </nav>
      ) : null}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-20 bg-ink text-paper">
      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 md:grid-cols-12 md:px-8 md:py-20">
        <div className="md:col-span-5">
          <p className="font-serif text-4xl tracking-tight">JP Rashidul</p>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-paper/80">
            Programmer. I write web applications, APIs, and tools. Dhaka. The code stays in your repository.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-8 text-sm md:col-span-7 md:grid-cols-3">
          <div>
            <p className="text-xs uppercase tracking-widest text-paper/60">Base</p>
            <ul className="mt-4 space-y-2 text-paper/85">
              <li>Dhaka</li>
              <li>Remote</li>
              <li className="pt-3">Weekdays</li>
              <li>Review overlap</li>
            </ul>
          </div>
          <div>
            <p className="text-xs uppercase tracking-widest text-paper/60">Index</p>
            <ul className="mt-4 space-y-2">
              {[
                ["/work", "Code"],
                ["/services", "Services"],
                ["/about", "About"],
                ["/principles", "Principles"],
                ["/journal", "Notes"],
                ["/open-source", "Open source"],
                ["/careers", "Hire"],
                ["/contact", "Contact"],
              ].map(([to, label]) => (
                <li key={to}>
                  <Link to={to} className="text-paper/85 hover:text-paper">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-xs uppercase tracking-widest text-paper/60">Write</p>
            <ul className="mt-4 space-y-2 text-paper/85">
              <li>hello@jprashidul.dev</li>
              <li>Programming & coding</li>
              <li className="pt-3">Weekdays, 9–6 local</li>
            </ul>
          </div>
        </div>
      </div>
      <div className="border-t border-paper/15">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-xs text-paper/60 md:flex-row md:justify-between md:px-8">
          <p>© 2026 JP Rashidul. Programming portfolio.</p>
          <p>Code, type, and paper.</p>
        </div>
      </div>
    </footer>
  );
}

export function PageIntro({ kicker, title, lede }: { kicker: string; title: string; lede: string }) {
  return (
    <header className="border-b border-line">
      <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        <p className="text-xs font-medium uppercase tracking-widest text-accent">{kicker}</p>
        <h1 className="mt-4 max-w-4xl font-serif text-4xl leading-tight text-ink md:text-6xl">{title}</h1>
        <p className="mt-6 max-w-2xl text-lg leading-relaxed text-muted">{lede}</p>
      </div>
    </header>
  );
}

export function Prose({ paragraphs, className }: { paragraphs: string[]; className?: string }) {
  return (
    <div className={cn("max-w-2xl space-y-6 text-base leading-relaxed text-ink md:text-lg", className)}>
      {paragraphs.map((paragraph, index) => (
        <p key={index}>{paragraph}</p>
      ))}
    </div>
  );
}
