import type { ComponentProps } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/cn";

export const buttonStyles = cva(
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-sm px-5 py-3 text-sm font-medium tracking-wide transition-colors duration-200 disabled:opacity-50",
  {
    variants: {
      variant: {
        primary: "bg-accent text-paper hover:bg-ink",
        secondary: "border border-ink bg-transparent text-ink hover:bg-ink hover:text-paper",
        quiet: "min-h-11 px-0 text-ink underline decoration-line underline-offset-4 hover:decoration-accent",
      },
    },
    defaultVariants: { variant: "primary" },
  },
);

export function Button({
  className,
  variant,
  ...props
}: ComponentProps<"button"> & VariantProps<typeof buttonStyles>) {
  return <button className={cn(buttonStyles({ variant }), className)} {...props} />;
}
