import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";
import { cn } from "@/lib/cn";
import { sectors, works } from "@/lib/site-content";

export const Route = createFileRoute("/work/")({
  head: () => ({
    meta: [{ title: "Code — JP Rashidul" }],
  }),
  component: WorkIndex,
});

function WorkIndex() {
  const [sector, setSector] = useState("All");
  const visible = useMemo(
    () => (sector === "All" ? works : works.filter((item) => item.sector === sector)),
    [sector],
  );

  return (
    <main>
      <PageIntro
        kicker="Code"
        title="Programs I can talk about."
        lede="Libraries, tools, and products. The interesting part is the constraint I was willing to encode — not a screenshot."
      />
      <div className="mx-auto max-w-6xl px-5 py-10 md:px-8">
        <div className="flex gap-2 overflow-x-auto pb-2" role="tablist" aria-label="Filter by sector">
          {sectors.map((item) => {
            const selected = item === sector;
            return (
              <button
                key={item}
                type="button"
                role="tab"
                aria-selected={selected}
                onClick={() => setSector(item)}
                className={cn(
                  "min-h-11 shrink-0 border px-4 text-sm",
                  selected ? "border-ink bg-ink text-paper" : "border-line bg-surface text-ink hover:border-ink",
                )}
              >
                {item}
              </button>
            );
          })}
        </div>
        <ul className="mt-6 border-b border-line">
          {visible.map((work) => (
            <li key={work.slug}>
              <Link
                to="/work/$slug"
                params={{ slug: work.slug }}
                className="group grid gap-3 border-t border-line py-8 md:grid-cols-12 md:gap-6"
              >
                <div className="md:col-span-7">
                  <p className="text-xs tabular-nums text-muted">
                    {work.index} · {work.sector} · {work.year}
                  </p>
                  <h2 className="mt-2 font-serif text-3xl leading-tight group-hover:text-accent md:text-4xl">{work.title}</h2>
                </div>
                <div className="md:col-span-5">
                  <p className="text-sm font-medium text-ink">{work.client}</p>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{work.summary}</p>
                </div>
              </Link>
            </li>
          ))}
        </ul>
        {visible.length === 0 ? <p className="py-16 text-muted">Nothing in this sector yet.</p> : null}
      </div>
    </main>
  );
}
