import { createFileRoute, Link } from "@tanstack/react-router";
import { buttonStyles } from "@/components/ui/button";
import { Prose } from "@/components/site-chrome";
import { getWork, works } from "@/lib/site-content";

export const Route = createFileRoute("/work/$slug")({
  head: ({ params }) => ({
    meta: [{ title: `${getWork(params.slug)?.title ?? "Code"} — JP Rashidul` }],
  }),
  component: CaseStudy,
});

function CaseStudy() {
  const { slug } = Route.useParams();
  const work = getWork(slug);

  if (!work) {
    return (
      <main className="mx-auto max-w-6xl px-5 py-24 md:px-8">
        <h1 className="font-serif text-4xl">That project is not on the record.</h1>
        <Link to="/work" className={buttonStyles({ variant: "quiet", className: "mt-6" })}>
          Back to the code
        </Link>
      </main>
    );
  }

  const index = works.findIndex((item) => item.slug === work.slug);
  const next = works[(index + 1) % works.length];

  return (
    <main>
      <article>
        <header className="border-b border-line">
          <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
            <Link to="/work" className="text-xs font-medium uppercase tracking-widest text-accent">
              Code · {work.index}
            </Link>
            <h1 className="mt-4 max-w-4xl font-serif text-4xl leading-tight md:text-6xl">{work.title}</h1>
            <p className="mt-6 max-w-2xl text-lg leading-relaxed text-muted">{work.summary}</p>
          </div>
        </header>
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-12 md:grid-cols-12 md:px-8 md:py-16">
          <dl className="grid grid-cols-2 gap-6 md:col-span-4 md:grid-cols-1">
            {[
              ["Client", work.client],
              ["Sector", work.sector],
              ["Year", work.year],
              ["Services", work.services.join(", ")],
            ].map(([label, value]) => (
              <div key={label}>
                <dt className="text-xs uppercase tracking-widest text-muted">{label}</dt>
                <dd className="mt-1 text-ink">{value}</dd>
              </div>
            ))}
          </dl>
          <div className="md:col-span-8">
            <p className="font-serif text-2xl leading-snug text-ink md:text-3xl">{work.outcome}</p>
            <dl className="mt-8 grid grid-cols-1 gap-px border border-line bg-line sm:grid-cols-3">
              {work.stats.map((stat) => (
                <div key={stat.label} className="bg-surface px-4 py-5">
                  <dt className="text-xs text-muted">{stat.label}</dt>
                  <dd className="mt-2 font-serif text-2xl tabular-nums">{stat.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
        <div className="mx-auto grid max-w-6xl gap-12 border-t border-line px-5 py-12 md:grid-cols-12 md:px-8 md:py-16">
          <div className="md:col-span-4">
            <h2 className="font-serif text-2xl">Brief</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted">{work.brief}</p>
            <h2 className="mt-10 font-serif text-2xl">Approach</h2>
            <ol className="mt-4 space-y-4">
              {work.approach.map((step, stepIndex) => (
                <li key={step} className="text-sm leading-relaxed text-ink">
                  <span className="mr-2 tabular-nums text-accent">0{stepIndex + 1}</span>
                  {step}
                </li>
              ))}
            </ol>
          </div>
          <Prose className="md:col-span-8" paragraphs={work.body} />
        </div>
      </article>
      <div className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 py-12 md:flex-row md:items-center md:justify-between md:px-8">
          <p className="text-sm text-muted">Next project</p>
          <Link to="/work/$slug" params={{ slug: next.slug }} className="font-serif text-3xl hover:text-accent">
            {next.title}
          </Link>
        </div>
      </div>
    </main>
  );
}
