import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";
import { cn } from "@/lib/cn";
import { roles } from "@/lib/site-content";

export const Route = createFileRoute("/careers")({
  head: () => ({ meta: [{ title: "Hire — JP Rashidul" }] }),
  component: CareersPage,
});

function CareersPage() {
  const [open, setOpen] = useState(roles[0]?.id ?? "");
  const [copied, setCopied] = useState<string | null>(null);

  async function copyRole(title: string, id: string) {
    const text = `To: hello@jprashidul.dev\nSubject: ${title} — JP Rashidul\n\nWhat needs to be programmed, what already exists, and when you need the first slice.`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(id);
    } catch {
      setCopied("failed");
    }
  }

  return (
    <main>
      <PageIntro
        kicker="Hire"
        title="Hire me to write the code."
        lede="I take a small number of programming jobs at a time. Web apps, APIs, tools, or a rescue. You get me in the diff, not a layer in front of it."
      />
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-12 md:grid-cols-12 md:px-8">
        <div className="md:col-span-4">
          <h2 className="font-serif text-2xl">How it starts</h2>
          <ol className="mt-4 space-y-4 text-sm leading-relaxed text-muted">
            <li>1. A note, not a portal. Say what should exist that does not.</li>
            <li>2. A working conversation about the code you already have.</li>
            <li>3. A first slice in your repository, so both of us can see the fit.</li>
            <li>4. Then the rest of the build, or a clean stop if it is the wrong job.</li>
          </ol>
        </div>
        <div className="md:col-span-8">
          <ul className="border-t border-line">
            {roles.map((role) => {
              const expanded = open === role.id;
              return (
                <li key={role.id} className="border-b border-line">
                  <button
                    type="button"
                    className="flex w-full min-h-16 items-start justify-between gap-4 py-5 text-left"
                    aria-expanded={expanded}
                    onClick={() => setOpen(expanded ? "" : role.id)}
                  >
                    <span>
                      <span className="block font-serif text-2xl">{role.title}</span>
                      <span className="mt-1 block text-sm text-muted">
                        {role.team} · {role.location} · {role.type}
                      </span>
                    </span>
                    <span className="pt-1 text-muted" aria-hidden>
                      {expanded ? "–" : "+"}
                    </span>
                  </button>
                  {expanded ? (
                    <div className="pb-6">
                      <p className="max-w-2xl text-sm leading-relaxed text-ink">{role.summary}</p>
                      <ul className="mt-4 space-y-2">
                        {role.points.map((point) => (
                          <li key={point} className="text-sm text-muted">
                            {point}
                          </li>
                        ))}
                      </ul>
                      <button
                        type="button"
                        onClick={() => copyRole(role.title, role.id)}
                        className={cn(
                          "mt-5 min-h-11 border border-ink px-4 text-sm",
                          copied === role.id ? "bg-accent text-paper border-accent" : "hover:bg-ink hover:text-paper",
                        )}
                      >
                        {copied === role.id ? "Note copied" : "Copy a hiring note"}
                      </button>
                      {copied === "failed" ? (
                        <p className="mt-2 text-sm text-muted">Copy failed. Write to hello@jprashidul.dev with the kind of work in the subject.</p>
                      ) : null}
                    </div>
                  ) : null}
                </li>
              );
            })}
          </ul>
        </div>
      </section>
    </main>
  );
}
