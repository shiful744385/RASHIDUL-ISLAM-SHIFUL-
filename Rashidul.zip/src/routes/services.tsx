import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";
import { buttonStyles } from "@/components/ui/button";
import { faqs, services } from "@/lib/site-content";

export const Route = createFileRoute("/services")({
  head: () => ({ meta: [{ title: "Services — JP Rashidul" }] }),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <main>
      <PageIntro
        kicker="Services"
        title="I join the repository. I do not send a deck and leave."
        lede="Most work is a block of programming: web, API, or a tool, shipped in your codebase. A short written diagnosis is the exception, and I label it as such."
      />
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        {services.map((service) => (
          <section key={service.index} className="grid gap-6 border-b border-line py-12 md:grid-cols-12 md:py-16">
            <div className="md:col-span-5">
              <p className="text-xs tabular-nums text-accent">{service.index}</p>
              <h2 className="mt-2 font-serif text-3xl md:text-4xl">{service.title}</h2>
              <p className="mt-4 text-muted">{service.summary}</p>
            </div>
            <ul className="md:col-span-6 md:col-start-7">
              {service.deliverables.map((item) => (
                <li key={item} className="border-t border-line py-3 text-sm text-ink last:border-b">
                  {item}
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
      <section className="border-b border-line bg-surface">
        <div className="mx-auto grid max-w-6xl gap-8 px-5 py-16 md:grid-cols-3 md:px-8">
          {[
            ["Slice", "2–6 weeks", "One path coded end to end, on your data, so you can see if the approach holds."],
            ["Build", "1–4 months", "I program in your repository and ship weekly. The note on Friday can say blocked."],
            ["Care", "After launch", "The slow query, the bad deploy, the dependency. A fix, plus a note for the next person."],
          ].map(([name, time, text]) => (
            <div key={name}>
              <p className="text-xs uppercase tracking-widest text-accent">{time}</p>
              <h2 className="mt-2 font-serif text-2xl">{name}</h2>
              <p className="mt-3 text-sm leading-relaxed text-muted">{text}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-5 py-16 md:px-8">
        <h2 className="font-serif text-3xl md:text-4xl">Questions before the first commit.</h2>
        <div className="mt-8 divide-y divide-line border-y border-line">
          {faqs.map((item) => (
            <details key={item.q} className="group py-5">
              <summary className="cursor-pointer list-none font-serif text-xl leading-snug md:text-2xl">
                <span className="flex items-start justify-between gap-4">
                  {item.q}
                  <span className="text-muted group-open:hidden" aria-hidden>
                    +
                  </span>
                  <span className="hidden text-muted group-open:inline" aria-hidden>
                    –
                  </span>
                </span>
              </summary>
              <p className="mt-3 max-w-3xl text-sm leading-relaxed text-muted">{item.a}</p>
            </details>
          ))}
        </div>
        <Link to="/contact" className={buttonStyles({ className: "mt-10" })}>
          Describe the code you need
        </Link>
      </section>
    </main>
  );
}
