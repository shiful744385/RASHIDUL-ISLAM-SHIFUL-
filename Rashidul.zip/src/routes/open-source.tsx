import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";
import { cn } from "@/lib/cn";
import { languages, repos } from "@/lib/site-content";

export const Route = createFileRoute("/open-source")({
  head: () => ({ meta: [{ title: "Open source — JP Rashidul" }] }),
  component: OpenSourcePage,
});

function OpenSourcePage() {
  const [language, setLanguage] = useState("All");
  const [query, setQuery] = useState("");

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return repos.filter((repo) => {
      const languageOk = language === "All" || repo.language === language;
      const text = `${repo.name} ${repo.description}`.toLowerCase();
      return languageOk && (needle.length === 0 || text.includes(needle));
    });
  }, [language, query]);

  const mix = languages.filter((item) => item !== "All").map((item) => ({
    language: item,
    count: repos.filter((repo) => repo.language === item).length,
  }));

  return (
    <main>
      <PageIntro
        kicker="Open source"
        title="Public code. One maintainer."
        lede="Tools I rebuilt until they stopped being private. They are not a client’s product. I am the person who answers."
      />
      <section className="border-b border-line bg-surface">
        <div className="mx-auto grid max-w-6xl gap-8 px-5 py-10 md:grid-cols-12 md:px-8">
          <div className="md:col-span-5">
            <p className="text-xs uppercase tracking-widest text-muted">Language mix</p>
            <ul className="mt-4 space-y-3">
              {mix.map((item) => (
                <li key={item.language}>
                  <div className="flex justify-between text-sm">
                    <span>{item.language}</span>
                    <span className="tabular-nums text-muted">{item.count}</span>
                  </div>
                  <div className="mt-1 h-1.5 bg-line">
                    <div className="h-full bg-accent" style={{ width: `${(item.count / repos.length) * 100}%` }} />
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="md:col-span-6 md:col-start-7">
            <label htmlFor="repo-search" className="text-xs uppercase tracking-widest text-muted">
              Search the catalogue
            </label>
            <input
              id="repo-search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Try ledger, prose, checklist"
              className="mt-3 min-h-11 w-full border border-line bg-canvas px-3 text-ink outline-none placeholder:text-muted"
            />
            <div className="mt-4 flex flex-wrap gap-2" role="tablist" aria-label="Filter by language">
              {languages.map((item) => {
                const selected = item === language;
                return (
                  <button
                    key={item}
                    type="button"
                    role="tab"
                    aria-selected={selected}
                    onClick={() => setLanguage(item)}
                    className={cn(
                      "min-h-11 border px-4 text-sm",
                      selected ? "border-ink bg-ink text-paper" : "border-line bg-canvas text-ink hover:border-ink",
                    )}
                  >
                    {item}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>
      <div className="mx-auto max-w-6xl px-5 py-8 md:px-8">
        <p className="text-sm text-muted">
          <span className="tabular-nums text-ink">{visible.length}</span> repositories
        </p>
        <ul className="mt-4 divide-y divide-line border-y border-line">
          {visible.map((repo) => (
            <li key={repo.name} className="grid gap-3 py-6 md:grid-cols-12 md:items-baseline">
              <div className="md:col-span-8">
                <h2 className="font-serif text-2xl">{repo.name}</h2>
                <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">{repo.description}</p>
              </div>
              <dl className="grid grid-cols-3 gap-3 text-sm md:col-span-4">
                <div>
                  <dt className="text-xs text-muted">Language</dt>
                  <dd className="mt-1">{repo.language}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted">Stars</dt>
                  <dd className="mt-1 tabular-nums">{repo.stars}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted">Updated</dt>
                  <dd className="mt-1">{repo.updated}</dd>
                </div>
              </dl>
              <p className="text-xs text-muted md:col-span-12">{repo.license}</p>
            </li>
          ))}
        </ul>
        {visible.length === 0 ? (
          <p className="py-16 text-muted">No repository matches that filter. Clear the search or choose All.</p>
        ) : null}
      </div>
    </main>
  );
}
