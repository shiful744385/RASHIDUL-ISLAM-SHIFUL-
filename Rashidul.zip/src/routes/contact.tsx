import { useState, type FormEvent, type ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: [{ title: "Contact — JP Rashidul" }] }),
  component: ContactPage,
});

type Fields = {
  name: string;
  email: string;
  company: string;
  budget: string;
  message: string;
};

const empty: Fields = { name: "", email: "", company: "", budget: "Exploring", message: "" };

function ContactPage() {
  const [fields, setFields] = useState<Fields>(empty);
  const [errors, setErrors] = useState<Partial<Record<keyof Fields, string>>>({});
  const [sent, setSent] = useState(false);

  function update<K extends keyof Fields>(key: K, value: Fields[K]) {
    setFields((current) => ({ ...current, [key]: value }));
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    const next: Partial<Record<keyof Fields, string>> = {};
    if (fields.name.trim().length < 2) next.name = "Tell me who to reply to.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.trim())) next.email = "That email does not look usable.";
    if (fields.message.trim().length < 30) next.message = "A few sentences on what needs to be programmed.";
    setErrors(next);
    if (Object.keys(next).length === 0) setSent(true);
  }

  return (
    <main>
      <PageIntro
        kicker="Contact"
        title="Tell me what needs to be programmed."
        lede="A short note is enough. What it should do, what already exists, and what must not break. I read the constraint before I talk about a stack."
      />
      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-14 md:grid-cols-12 md:px-8">
        <div className="md:col-span-4">
          <h2 className="font-serif text-2xl">JP Rashidul</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted">Programmer · Dhaka · remote</p>
          <p className="mt-6 text-sm text-ink">hello@jprashidul.dev</p>
          <p className="mt-8 text-sm leading-relaxed text-muted">
            This form stays in the browser. It is a portfolio demo, so nothing is emailed. On a real site this note would reach me.
          </p>
        </div>
        <div className="md:col-span-8">
          {sent ? (
            <div className="border border-line bg-surface p-8">
              <p className="text-xs uppercase tracking-widest text-accent">Noted</p>
              <h2 className="mt-3 font-serif text-3xl">Thank you, {fields.name.trim().split(" ")[0]}.</h2>
              <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted">
                If this were the live site, I would read it and reply — including when the honest answer is that I am the wrong programmer. Here, the note stayed on this page.
              </p>
              <dl className="mt-6 space-y-2 text-sm">
                <div className="flex justify-between gap-4 border-b border-line py-2">
                  <dt className="text-muted">Company</dt>
                  <dd>{fields.company || "—"}</dd>
                </div>
                <div className="flex justify-between gap-4 border-b border-line py-2">
                  <dt className="text-muted">Shape</dt>
                  <dd>{fields.budget}</dd>
                </div>
              </dl>
              <Button
                variant="secondary"
                className="mt-8"
                onClick={() => {
                  setSent(false);
                  setFields(empty);
                }}
              >
                Write another note
              </Button>
            </div>
          ) : (
            <form onSubmit={submit} noValidate className="space-y-5">
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Name" error={errors.name} htmlFor="name">
                  <input
                    id="name"
                    value={fields.name}
                    onChange={(event) => update("name", event.target.value)}
                    autoComplete="name"
                    className={inputClass}
                  />
                </Field>
                <Field label="Email" error={errors.email} htmlFor="email">
                  <input
                    id="email"
                    type="email"
                    value={fields.email}
                    onChange={(event) => update("email", event.target.value)}
                    autoComplete="email"
                    className={inputClass}
                  />
                </Field>
              </div>
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Organisation" error={errors.company} htmlFor="company">
                  <input
                    id="company"
                    value={fields.company}
                    onChange={(event) => update("company", event.target.value)}
                    autoComplete="organization"
                    className={inputClass}
                  />
                </Field>
                <Field label="What you need" htmlFor="budget">
                  <select
                    id="budget"
                    value={fields.budget}
                    onChange={(event) => update("budget", event.target.value)}
                    className={inputClass}
                  >
                    <option>Exploring</option>
                    <option>A discovery, a few weeks</option>
                    <option>A build this year</option>
                    <option>Care for something live</option>
                    <option>Not sure yet</option>
                  </select>
                </Field>
              </div>
              <Field label="The constraint" error={errors.message} htmlFor="message">
                <textarea
                  id="message"
                  rows={7}
                  value={fields.message}
                  onChange={(event) => update("message", event.target.value)}
                  className={`${inputClass} py-3`}
                />
              </Field>
              <Button type="submit">Send the note</Button>
            </form>
          )}
        </div>
      </div>
    </main>
  );
}

const inputClass =
  "min-h-11 w-full border border-line bg-surface px-3 text-ink outline-none focus-visible:border-accent";

function Field({
  label,
  htmlFor,
  error,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="text-sm font-medium text-ink">
        {label}
      </label>
      <div className="mt-2">{children}</div>
      {error ? <p className="mt-1 text-sm text-accent">{error}</p> : null}
    </div>
  );
}
