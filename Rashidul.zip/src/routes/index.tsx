import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { buttonStyles } from "@/components/ui/button";
import { cn } from "@/lib/cn";
import { articles, method, services, stack, works } from "@/lib/site-content";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [{ title: "JP Rashidul — Programming" }],
  }),
  component: Home,
});

function Home() {
  return (
    <main>
      <section className="mx-auto max-w-6xl px-5 pt-16 pb-16 md:px-8 md:pt-24 md:pb-24">
        <p className="text-xs font-medium uppercase tracking-widest text-accent">JP Rashidul · Programmer · Dhaka</p>
        <h1 className="mt-5 max-w-5xl font-serif text-5xl leading-tight text-ink md:text-7xl">
          I write code that another programmer can change.
        </h1>
        <p className="mt-6 max-w-2xl text-lg leading-relaxed text-muted">
          Programming and coding for products that have to work on an ordinary day. Web applications, APIs, and the tools teams stop rewriting. The work is the diff.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Link to="/work" className={buttonStyles()}>
            Selected code
          </Link>
          <Link to="/contact" className={buttonStyles({ variant: "secondary" })}>
            Hire me
          </Link>
        </div>
        <dl className="mt-14 grid grid-cols-2 gap-px border border-line bg-line sm:grid-cols-4">
          {[
            ["Web", "Apps in TypeScript"],
            ["API", "Services that fail honestly"],
            ["Tools", "CLIs and libraries"],
            ["Dhaka", "Remote, on your repo"],
          ].map(([value, label]) => (
            <div key={label} className="bg-surface px-4 py-5">
              <dt className="font-serif text-3xl tabular-nums text-ink">{value}</dt>
              <dd className="mt-1 text-sm text-muted">{label}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="border-y border-line bg-surface">
        <div className="mx-auto max-w-6xl px-5 py-10 md:px-8">
          <p className="text-xs uppercase tracking-widest text-muted">Languages and tools</p>
          <ul className="mt-5 flex flex-wrap gap-x-8 gap-y-3">
            {stack.map((item) => (
              <li key={item} className="font-serif text-xl text-ink md:text-2xl">
                {item}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        <div className="flex items-end justify-between gap-4">
          <h2 className="font-serif text-3xl md:text-5xl">Selected code</h2>
          <Link to="/work" className={buttonStyles({ variant: "quiet" })}>
            All projects
          </Link>
        </div>
        <ul className="mt-8 border-b border-line">
          {works.slice(0, 4).map((work) => (
            <li key={work.slug}>
              <Link
                to="/work/$slug"
                params={{ slug: work.slug }}
                className="group grid grid-cols-1 gap-2 border-t border-line py-7 md:grid-cols-12 md:items-baseline md:gap-6"
              >
                <span className="text-sm tabular-nums text-muted md:col-span-1">{work.index}</span>
                <span className="font-serif text-2xl leading-tight text-ink group-hover:text-accent md:col-span-6 md:text-3xl">
                  {work.title}
                </span>
                <span className="text-muted md:col-span-3">{work.client}</span>
                <span className="flex items-center justify-between text-sm text-muted md:col-span-2">
                  {work.year}
                  <ArrowUpRight className="size-4 text-ink opacity-0 transition-opacity duration-200 group-hover:opacity-100" />
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <section className="border-y border-line bg-accent-soft">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-12 md:px-8 md:py-20">
          <div className="md:col-span-4">
            <p className="text-xs font-medium uppercase tracking-widest text-accent">Coding</p>
            <h2 className="mt-3 font-serif text-3xl md:text-4xl">Four kinds of programming. I do the typing.</h2>
            <Link to="/services" className={cnQuiet}>
              What I take on
            </Link>
          </div>
          <ol className="grid gap-8 md:col-span-8 sm:grid-cols-2">
            {services.map((service) => (
              <li key={service.index}>
                <p className="text-xs tabular-nums text-accent">{service.index}</p>
                <h3 className="mt-2 font-serif text-2xl">{service.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{service.summary}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        <h2 className="max-w-3xl font-serif text-3xl md:text-5xl">How a piece of code gets made.</h2>
        <ol className="mt-10 divide-y divide-line border-y border-line">
          {method.map((step) => (
            <li key={step.index} className="grid gap-3 py-6 md:grid-cols-12 md:items-baseline">
              <span className="text-sm tabular-nums text-accent md:col-span-1">{step.index}</span>
              <h3 className="font-serif text-2xl md:col-span-3">{step.title}</h3>
              <p className="text-muted md:col-span-8">{step.text}</p>
            </li>
          ))}
        </ol>
        <Link to="/principles" className="mt-8 inline-flex text-sm font-medium text-ink underline decoration-line underline-offset-4 hover:decoration-accent">
          Read the principles
        </Link>
      </section>

      <section className="bg-ink text-paper">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-2 md:px-8 md:py-20">
          <div>
            <p className="text-xs uppercase tracking-widest text-paper/60">Open source</p>
            <h2 className="mt-3 font-serif text-3xl md:text-5xl">Code I was tired of rewriting.</h2>
            <p className="mt-4 max-w-md text-paper/75">
              Client work stays private. Libraries and tools that survived three projects are public, with my name on them and a license you can read.
            </p>
            <Link
              to="/open-source"
              className={cn(buttonStyles({ variant: "secondary" }), "mt-8 border-paper text-paper hover:bg-paper hover:text-ink")}
            >
              Browse the catalogue
            </Link>
          </div>
          <ul className="divide-y divide-paper/20 border-y border-paper/20">
            {[
              ["kiln-ui", "Dense interface components"],
              ["ledgerkit", "Append-only product events"],
              ["paperdiff", "Sentence-level prose diffs"],
              ["formidle", "Forms as a state machine"],
            ].map(([name, line]) => (
              <li key={name} className="flex items-baseline justify-between gap-4 py-4">
                <span className="font-serif text-2xl">{name}</span>
                <span className="text-sm text-paper/65">{line}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        <div className="flex items-end justify-between gap-4">
          <h2 className="font-serif text-3xl md:text-5xl">Journal</h2>
          <Link to="/journal" className={buttonStyles({ variant: "quiet" })}>
            All notes
          </Link>
        </div>
        <ul className="mt-8 grid gap-6 md:grid-cols-3">
          {articles.slice(0, 3).map((article) => (
            <li key={article.slug} className="border border-line bg-surface p-6">
              <p className="text-xs uppercase tracking-widest text-accent">{article.kicker}</p>
              <h3 className="mt-3 font-serif text-2xl leading-tight">
                <Link to="/journal/$slug" params={{ slug: article.slug }} className="hover:text-accent">
                  {article.title}
                </Link>
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-muted">{article.dek}</p>
              <p className="mt-6 text-xs text-muted">
                {article.date} · {article.minutes} min
              </p>
            </li>
          ))}
        </ul>
      </section>

      <section className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-8 px-5 py-16 md:flex-row md:items-end md:justify-between md:px-8 md:py-20">
          <div>
            <h2 className="max-w-xl font-serif text-4xl leading-tight md:text-5xl">Need something programmed?</h2>
            <p className="mt-4 max-w-lg text-muted">Send the constraint. A deck is optional. If I am the wrong coder, I will say so before anyone wastes a sprint.</p>
          </div>
          <Link to="/contact" className={buttonStyles()}>
            Write to JP
          </Link>
        </div>
      </section>
    </main>
  );
}

const cnQuiet = "mt-6 inline-flex text-sm font-medium text-ink underline decoration-line underline-offset-4 hover:decoration-accent";
