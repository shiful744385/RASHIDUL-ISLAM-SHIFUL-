import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";
import { buttonStyles } from "@/components/ui/button";
import { stack } from "@/lib/site-content";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: [{ title: "About — JP Rashidul" }] }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <main>
      <PageIntro
        kicker="About"
        title="JP Rashidul. I program for a living."
        lede="I write software — web apps, APIs, and the small tools teams get tired of rewriting. Based in Dhaka. The work is coding, reviewed in the open, left in a state another programmer can change."
      />
      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 md:grid-cols-12 md:px-8">
        <div className="space-y-6 text-base leading-relaxed text-ink md:col-span-7 md:text-lg">
          <p>
            My name is JP Rashidul. People hire me when a product needs to be programmed, not presented. I sit with the constraint, model the data, and ship code into the repository that already exists.
          </p>
          <p>
            The stack is practical. TypeScript and React when the surface is a web app. Node, Python, or Go when the work is an API, a job, or a CLI. Rust when the core is a library that should be fast and small. Postgres when the data has a shape worth protecting.
          </p>
          <p>
            I do not run a studio and I do not hand the typing to someone else. The person you write to is the person in the diff. If the job is a brand campaign, a native game, or a research model, I am the wrong programmer, and I will say so.
          </p>
          <p>
            Public code lives on the open-source page. Client code stays in the client’s org. The principles page is how I decide, when a task starts to swell, what I will not build.
          </p>
        </div>
        <aside className="h-fit border border-line bg-surface p-6 md:col-span-4 md:col-start-9">
          <p className="text-xs uppercase tracking-widest text-muted">At a glance</p>
          <dl className="mt-4 space-y-4 text-sm">
            {[
              ["Name", "JP Rashidul"],
              ["Work", "Programming"],
              ["Base", "Dhaka"],
              ["Focus", "Web, APIs, tools"],
            ].map(([label, value]) => (
              <div key={label} className="flex items-baseline justify-between gap-4 border-b border-line pb-3">
                <dt className="text-muted">{label}</dt>
                <dd className="font-medium">{value}</dd>
              </div>
            ))}
          </dl>
        </aside>
      </div>
      <section className="border-y border-line bg-surface">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8">
          <h2 className="font-serif text-3xl md:text-4xl">What I code in</h2>
          <ul className="mt-8 grid gap-px border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
            {stack.map((item) => (
              <li key={item} className="bg-surface px-5 py-6">
                <p className="font-serif text-2xl text-ink">{item}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <section className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-6 px-5 py-14 md:flex-row md:items-center md:justify-between md:px-8">
          <p className="max-w-xl font-serif text-2xl">The rules I code by are written down.</p>
          <Link to="/principles" className={buttonStyles({ variant: "secondary" })}>
            Read the principles
          </Link>
        </div>
      </section>
    </main>
  );
}
