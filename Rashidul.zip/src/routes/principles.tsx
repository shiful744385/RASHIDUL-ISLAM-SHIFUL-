import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";
import { buttonStyles } from "@/components/ui/button";
import { principles } from "@/lib/site-content";

export const Route = createFileRoute("/principles")({
  head: () => ({ meta: [{ title: "Principles — JP Rashidul" }] }),
  component: PrinciplesPage,
});

function PrinciplesPage() {
  return (
    <main>
      <PageIntro
        kicker="Principles"
        title="How I decide what to code."
        lede="These are not values on a wall. They are the rules I use when a task starts to swell. If you hire me, this is the standard already in force."
      />
      <ol className="mx-auto max-w-6xl px-5 md:px-8">
        {principles.map((item, index) => (
          <li key={item.title} className="grid gap-4 border-b border-line py-12 md:grid-cols-12 md:py-14">
            <p className="text-sm tabular-nums text-accent md:col-span-2">{String(index + 1).padStart(2, "0")}</p>
            <div className="md:col-span-9">
              <h2 className="font-serif text-3xl md:text-4xl">{item.title}</h2>
              <p className="mt-4 max-w-3xl text-base leading-relaxed text-muted md:text-lg">{item.body}</p>
            </div>
          </li>
        ))}
      </ol>
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 py-14 md:flex-row md:items-center md:justify-between md:px-8">
        <p className="text-muted">If this is how you want the code written, send the constraint.</p>
        <Link to="/contact" className={buttonStyles()}>
          Write to JP
        </Link>
      </div>
    </main>
  );
}
