import { createFileRoute, Link } from "@tanstack/react-router";
import { Prose } from "@/components/site-chrome";
import { buttonStyles } from "@/components/ui/button";
import { articles, getArticle } from "@/lib/site-content";

export const Route = createFileRoute("/journal/$slug")({
  head: ({ params }) => ({
    meta: [{ title: `${getArticle(params.slug)?.title ?? "Notes"} — JP Rashidul` }],
  }),
  component: ArticlePage,
});

function ArticlePage() {
  const { slug } = Route.useParams();
  const article = getArticle(slug);

  if (!article) {
    return (
      <main className="mx-auto max-w-6xl px-5 py-24 md:px-8">
        <h1 className="font-serif text-4xl">That note is not here.</h1>
        <Link to="/journal" className={buttonStyles({ variant: "quiet", className: "mt-6" })}>
          Back to the notes
        </Link>
      </main>
    );
  }

  const more = articles.filter((item) => item.slug !== article.slug).slice(0, 2);

  return (
    <main>
      <article>
        <header className="border-b border-line">
          <div className="mx-auto max-w-3xl px-5 py-16 md:px-8 md:py-24">
            <p className="text-xs font-medium uppercase tracking-widest text-accent">{article.kicker}</p>
            <h1 className="mt-4 font-serif text-4xl leading-tight md:text-6xl">{article.title}</h1>
            <p className="mt-6 text-lg leading-relaxed text-muted">{article.dek}</p>
            <p className="mt-8 text-sm text-muted">
              {article.author}, {article.role} · {article.date} · {article.minutes} min read
            </p>
          </div>
        </header>
        <div className="mx-auto max-w-3xl px-5 py-12 md:px-8 md:py-16">
          <Prose paragraphs={article.paragraphs} />
        </div>
      </article>
      <section className="border-t border-line">
        <div className="mx-auto max-w-6xl px-5 py-14 md:px-8">
          <p className="text-xs uppercase tracking-widest text-muted">Continue</p>
          <ul className="mt-6 grid gap-6 md:grid-cols-2">
            {more.map((item) => (
              <li key={item.slug}>
                <Link to="/journal/$slug" params={{ slug: item.slug }} className="font-serif text-2xl hover:text-accent">
                  {item.title}
                </Link>
                <p className="mt-2 text-sm text-muted">{item.dek}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </main>
  );
}
