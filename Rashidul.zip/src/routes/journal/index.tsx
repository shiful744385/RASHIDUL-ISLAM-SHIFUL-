import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/site-chrome";
import { articles } from "@/lib/site-content";

export const Route = createFileRoute("/journal/")({
  head: () => ({ meta: [{ title: "Notes — JP Rashidul" }] }),
  component: JournalIndex,
});

function JournalIndex() {
  return (
    <main>
      <PageIntro
        kicker="Notes"
        title="Notes from the editor."
        lede="I write when a rule has survived more than one codebase. Not a content calendar. A record of how I program."
      />
      <ul className="mx-auto max-w-6xl border-b border-line px-5 md:px-8">
        {articles.map((article) => (
          <li key={article.slug} className="border-t border-line">
            <Link
              to="/journal/$slug"
              params={{ slug: article.slug }}
              className="group grid gap-4 py-10 md:grid-cols-12 md:items-baseline"
            >
              <p className="text-xs uppercase tracking-widest text-accent md:col-span-2">{article.kicker}</p>
              <div className="md:col-span-7">
                <h2 className="font-serif text-3xl leading-tight group-hover:text-accent md:text-4xl">{article.title}</h2>
                <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted">{article.dek}</p>
              </div>
              <p className="text-sm text-muted md:col-span-3 md:text-right">
                {article.date}
                <span className="mt-1 block">{article.minutes} min · {article.author}</span>
              </p>
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
