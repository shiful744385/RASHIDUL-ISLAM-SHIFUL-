import { chromium } from "playwright";
import { pathToFileURL } from "node:url";

const browser = await chromium.launch();
const page = await browser.newPage({
  viewport: { width: 1200, height: 630 },
  deviceScaleFactor: 2,
});
await page.goto(pathToFileURL("/workspace/.grok/og-card.html").href, { waitUntil: "load" });
await page.evaluate(() => document.fonts.ready);
const metrics = await page.evaluate(() => {
  const h1 = document.querySelector("h1");
  const p = document.querySelector("p");
  const lock = document.querySelector(".lockup");
  const hr = h1.getBoundingClientRect();
  const pr = p.getBoundingClientRect();
  const lr = lock.getBoundingClientRect();
  return {
    title: h1.textContent,
    caption: p.textContent,
    titleW: Math.round(hr.width),
    titleH: Math.round(hr.height),
    captionW: Math.round(pr.width),
    lockW: Math.round(lr.width),
    lockH: Math.round(lr.height),
    lockTop: Math.round(lr.top),
    lockBottom: Math.round(630 - lr.bottom),
  };
});
console.log(JSON.stringify(metrics));
await page.screenshot({ path: "/workspace/.grok/og-raw.png", type: "png" });

const icon = await browser.newPage({
  viewport: { width: 160, height: 180 },
  deviceScaleFactor: 2,
});
await icon.setContent(`<!doctype html><html><body style="margin:0;background:#cfc8bc;display:flex;gap:16px;align-items:flex-start;padding:16px">
<img width="16" height="16" src="${pathToFileURL("/workspace/.grok/favicon.svg.tmp").href}">
<img width="32" height="32" src="${pathToFileURL("/workspace/.grok/favicon.svg.tmp").href}">
<img width="64" height="64" src="${pathToFileURL("/workspace/.grok/favicon.svg.tmp").href}">
</body></html>`, { waitUntil: "load" });
await icon.screenshot({ path: "/workspace/.grok/favicon-preview.png" });
await browser.close();
