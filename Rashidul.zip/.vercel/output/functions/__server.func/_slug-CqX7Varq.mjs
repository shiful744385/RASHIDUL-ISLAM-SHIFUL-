import { J as require_jsx_runtime, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { h as buttonStyles, i as getWork, p as works } from "./_ssr/site-content-BmDfEnfW.mjs";
import { a as Prose, n as Route } from "./_ssr/router-DTCHPS2r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-CqX7Varq.js
var import_jsx_runtime = require_jsx_runtime();
function CaseStudy() {
	const { slug } = Route.useParams();
	const work = getWork(slug);
	if (!work) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-5 py-24 md:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-serif text-4xl",
			children: "That project is not on the record."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/work",
			className: buttonStyles({
				variant: "quiet",
				className: "mt-6"
			}),
			children: "Back to the code"
		})]
	});
	const index = works.findIndex((item) => item.slug === work.slug);
	const next = works[(index + 1) % works.length];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/work",
						className: "text-xs font-medium uppercase tracking-widest text-accent",
						children: ["Code · ", work.index]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 max-w-4xl font-serif text-4xl leading-tight md:text-6xl",
						children: work.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-2xl text-lg leading-relaxed text-muted",
						children: work.summary
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-5 py-12 md:grid-cols-12 md:px-8 md:py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "grid grid-cols-2 gap-6 md:col-span-4 md:grid-cols-1",
				children: [
					["Client", work.client],
					["Sector", work.sector],
					["Year", work.year],
					["Services", work.services.join(", ")]
				].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-xs uppercase tracking-widest text-muted",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-1 text-ink",
					children: value
				})] }, label))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-serif text-2xl leading-snug text-ink md:text-3xl",
					children: work.outcome
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "mt-8 grid grid-cols-1 gap-px border border-line bg-line sm:grid-cols-3",
					children: work.stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-surface px-4 py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted",
							children: stat.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-2 font-serif text-2xl tabular-nums",
							children: stat.value
						})]
					}, stat.label))
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-12 border-t border-line px-5 py-12 md:grid-cols-12 md:px-8 md:py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Brief"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-muted",
						children: work.brief
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-10 font-serif text-2xl",
						children: "Approach"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-4 space-y-4",
						children: work.approach.map((step, stepIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "text-sm leading-relaxed text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mr-2 tabular-nums text-accent",
								children: ["0", stepIndex + 1]
							}), step]
						}, step))
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, {
				className: "md:col-span-8",
				paragraphs: work.body
			})]
		})
	] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-4 px-5 py-12 md:flex-row md:items-center md:justify-between md:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Next project"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/work/$slug",
				params: { slug: next.slug },
				className: "font-serif text-3xl hover:text-accent",
				children: next.title
			})]
		})
	})] });
}
//#endregion
export { CaseStudy as component };
