import { i as __toESM } from "../_runtime.mjs";
import { J as require_jsx_runtime, b as Link, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as cn, p as works, u as sectors } from "./site-content-BmDfEnfW.mjs";
import { i as PageIntro } from "./router-DTCHPS2r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/work-VgVacd4D.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WorkIndex() {
	const [sector, setSector] = (0, import_react.useState)("All");
	const visible = (0, import_react.useMemo)(() => sector === "All" ? works : works.filter((item) => item.sector === sector), [sector]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		kicker: "Code",
		title: "Programs I can talk about.",
		lede: "Libraries, tools, and products. The interesting part is the constraint I was willing to encode — not a screenshot."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-5 py-10 md:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-2",
				role: "tablist",
				"aria-label": "Filter by sector",
				children: sectors.map((item) => {
					const selected = item === sector;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": selected,
						onClick: () => setSector(item),
						className: cn("min-h-11 shrink-0 border px-4 text-sm", selected ? "border-ink bg-ink text-paper" : "border-line bg-surface text-ink hover:border-ink"),
						children: item
					}, item);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 border-b border-line",
				children: visible.map((work) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/work/$slug",
					params: { slug: work.slug },
					className: "group grid gap-3 border-t border-line py-8 md:grid-cols-12 md:gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "md:col-span-7",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs tabular-nums text-muted",
							children: [
								work.index,
								" · ",
								work.sector,
								" · ",
								work.year
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-serif text-3xl leading-tight group-hover:text-accent md:text-4xl",
							children: work.title
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "md:col-span-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-ink",
							children: work.client
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: work.summary
						})]
					})]
				}) }, work.slug))
			}),
			visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-16 text-muted",
				children: "Nothing in this sector yet."
			}) : null
		]
	})] });
}
//#endregion
export { WorkIndex as component };
