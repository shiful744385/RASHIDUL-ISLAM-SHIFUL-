import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as buttonStyles, s as principles } from "./site-content-BmDfEnfW.mjs";
import { i as PageIntro } from "./router-DTCHPS2r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/principles-BtOFhNZH.js
var import_jsx_runtime = require_jsx_runtime();
function PrinciplesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			kicker: "Principles",
			title: "How I decide what to code.",
			lede: "These are not values on a wall. They are the rules I use when a task starts to swell. If you hire me, this is the standard already in force."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mx-auto max-w-6xl px-5 md:px-8",
			children: principles.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "grid gap-4 border-b border-line py-12 md:grid-cols-12 md:py-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm tabular-nums text-accent md:col-span-2",
					children: String(index + 1).padStart(2, "0")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-9",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-3xl md:text-4xl",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-3xl text-base leading-relaxed text-muted md:text-lg",
						children: item.body
					})]
				})]
			}, item.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-4 px-5 py-14 md:flex-row md:items-center md:justify-between md:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "If this is how you want the code written, send the constraint."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/contact",
				className: buttonStyles(),
				children: "Write to JP"
			})]
		})
	] });
}
//#endregion
export { PrinciplesPage as component };
