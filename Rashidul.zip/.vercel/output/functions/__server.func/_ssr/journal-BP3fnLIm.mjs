import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as articles } from "./site-content-BmDfEnfW.mjs";
import { i as PageIntro } from "./router-DTCHPS2r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/journal-BP3fnLIm.js
var import_jsx_runtime = require_jsx_runtime();
function JournalIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		kicker: "Notes",
		title: "Notes from the editor.",
		lede: "I write when a rule has survived more than one codebase. Not a content calendar. A record of how I program."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mx-auto max-w-6xl border-b border-line px-5 md:px-8",
		children: articles.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/journal/$slug",
				params: { slug: article.slug },
				className: "group grid gap-4 py-10 md:grid-cols-12 md:items-baseline",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-widest text-accent md:col-span-2",
						children: article.kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "md:col-span-7",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-3xl leading-tight group-hover:text-accent md:text-4xl",
							children: article.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xl text-sm leading-relaxed text-muted",
							children: article.dek
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted md:col-span-3 md:text-right",
						children: [article.date, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 block",
							children: [
								article.minutes,
								" min · ",
								article.author
							]
						})]
					})
				]
			})
		}, article.slug))
	})] });
}
//#endregion
export { JournalIndex as component };
