import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as stack, h as buttonStyles } from "./site-content-BmDfEnfW.mjs";
import { i as PageIntro } from "./router-DTCHPS2r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-CMpTIRUw.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			kicker: "About",
			title: "JP Rashidul. I program for a living.",
			lede: "I write software — web apps, APIs, and the small tools teams get tired of rewriting. Based in Dhaka. The work is coding, reviewed in the open, left in a state another programmer can change."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-12 px-5 py-16 md:grid-cols-12 md:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6 text-base leading-relaxed text-ink md:col-span-7 md:text-lg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "My name is JP Rashidul. People hire me when a product needs to be programmed, not presented. I sit with the constraint, model the data, and ship code into the repository that already exists." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The stack is practical. TypeScript and React when the surface is a web app. Node, Python, or Go when the work is an API, a job, or a CLI. Rust when the core is a library that should be fast and small. Postgres when the data has a shape worth protecting." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I do not run a studio and I do not hand the typing to someone else. The person you write to is the person in the diff. If the job is a brand campaign, a native game, or a research model, I am the wrong programmer, and I will say so." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Public code lives on the open-source page. Client code stays in the client’s org. The principles page is how I decide, when a task starts to swell, what I will not build." })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "h-fit border border-line bg-surface p-6 md:col-span-4 md:col-start-9",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-muted",
					children: "At a glance"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "mt-4 space-y-4 text-sm",
					children: [
						["Name", "JP Rashidul"],
						["Work", "Programming"],
						["Base", "Dhaka"],
						["Focus", "Web, APIs, tools"]
					].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-4 border-b border-line pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-medium",
							children: value
						})]
					}, label))
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16 md:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-3xl md:text-4xl",
					children: "What I code in"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 grid gap-px border border-line bg-line sm:grid-cols-2 lg:grid-cols-4",
					children: stack.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "bg-surface px-5 py-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-serif text-2xl text-ink",
							children: item
						})
					}, item))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-6 px-5 py-14 md:flex-row md:items-center md:justify-between md:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xl font-serif text-2xl",
					children: "The rules I code by are written down."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/principles",
					className: buttonStyles({ variant: "secondary" }),
					children: "Read the principles"
				})]
			})
		})
	] });
}
//#endregion
export { AboutPage as component };
