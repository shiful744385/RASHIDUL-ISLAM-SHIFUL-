import { i as __toESM } from "../_runtime.mjs";
import { J as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as Button } from "./site-content-BmDfEnfW.mjs";
import { i as PageIntro } from "./router-DTCHPS2r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-B-5GSRj6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var empty = {
	name: "",
	email: "",
	company: "",
	budget: "Exploring",
	message: ""
};
function ContactPage() {
	const [fields, setFields] = (0, import_react.useState)(empty);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [sent, setSent] = (0, import_react.useState)(false);
	function update(key, value) {
		setFields((current) => ({
			...current,
			[key]: value
		}));
	}
	function submit(event) {
		event.preventDefault();
		const next = {};
		if (fields.name.trim().length < 2) next.name = "Tell me who to reply to.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.trim())) next.email = "That email does not look usable.";
		if (fields.message.trim().length < 30) next.message = "A few sentences on what needs to be programmed.";
		setErrors(next);
		if (Object.keys(next).length === 0) setSent(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		kicker: "Contact",
		title: "Tell me what needs to be programmed.",
		lede: "A short note is enough. What it should do, what already exists, and what must not break. I read the constraint before I talk about a stack."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-12 px-5 py-14 md:grid-cols-12 md:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:col-span-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "JP Rashidul"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted",
					children: "Programmer · Dhaka · remote"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-ink",
					children: "hello@jprashidul.dev"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-sm leading-relaxed text-muted",
					children: "This form stays in the browser. It is a portfolio demo, so nothing is emailed. On a real site this note would reach me."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "md:col-span-8",
			children: sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-line bg-surface p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-widest text-accent",
						children: "Noted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-3 font-serif text-3xl",
						children: [
							"Thank you, ",
							fields.name.trim().split(" ")[0],
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-sm leading-relaxed text-muted",
						children: "If this were the live site, I would read it and reply — including when the honest answer is that I am the wrong programmer. Here, the note stayed on this page."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-6 space-y-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4 border-b border-line py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Company"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: fields.company || "—" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4 border-b border-line py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Shape"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: fields.budget })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "mt-8",
						onClick: () => {
							setSent(false);
							setFields(empty);
						},
						children: "Write another note"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				noValidate: true,
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-5 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Name",
							error: errors.name,
							htmlFor: "name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "name",
								value: fields.name,
								onChange: (event) => update("name", event.target.value),
								autoComplete: "name",
								className: inputClass
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Email",
							error: errors.email,
							htmlFor: "email",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "email",
								type: "email",
								value: fields.email,
								onChange: (event) => update("email", event.target.value),
								autoComplete: "email",
								className: inputClass
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-5 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Organisation",
							error: errors.company,
							htmlFor: "company",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "company",
								value: fields.company,
								onChange: (event) => update("company", event.target.value),
								autoComplete: "organization",
								className: inputClass
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "What you need",
							htmlFor: "budget",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								id: "budget",
								value: fields.budget,
								onChange: (event) => update("budget", event.target.value),
								className: inputClass,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Exploring" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "A discovery, a few weeks" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "A build this year" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Care for something live" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Not sure yet" })
								]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "The constraint",
						error: errors.message,
						htmlFor: "message",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "message",
							rows: 7,
							value: fields.message,
							onChange: (event) => update("message", event.target.value),
							className: `${inputClass} py-3`
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Send the note"
					})
				]
			})
		})]
	})] });
}
var inputClass = "min-h-11 w-full border border-line bg-surface px-3 text-ink outline-none focus-visible:border-accent";
function Field({ label, htmlFor, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor,
			className: "text-sm font-medium text-ink",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2",
			children
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-accent",
			children: error
		}) : null
	] });
}
//#endregion
export { ContactPage as component };
