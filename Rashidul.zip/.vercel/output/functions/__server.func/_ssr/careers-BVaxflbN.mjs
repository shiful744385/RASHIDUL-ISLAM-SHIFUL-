import { i as __toESM } from "../_runtime.mjs";
import { J as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as cn, l as roles } from "./site-content-BmDfEnfW.mjs";
import { i as PageIntro } from "./router-DTCHPS2r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/careers-BVaxflbN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CareersPage() {
	const [open, setOpen] = (0, import_react.useState)(roles[0]?.id ?? "");
	const [copied, setCopied] = (0, import_react.useState)(null);
	async function copyRole(title, id) {
		const text = `To: hello@jprashidul.dev\nSubject: ${title} — JP Rashidul\n\nWhat needs to be programmed, what already exists, and when you need the first slice.`;
		try {
			await navigator.clipboard.writeText(text);
			setCopied(id);
		} catch {
			setCopied("failed");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		kicker: "Hire",
		title: "Hire me to write the code.",
		lede: "I take a small number of programming jobs at a time. Web apps, APIs, tools, or a rescue. You get me in the diff, not a layer in front of it."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto grid max-w-6xl gap-10 px-5 py-12 md:grid-cols-12 md:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:col-span-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-2xl",
				children: "How it starts"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-4 space-y-4 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1. A note, not a portal. Say what should exist that does not." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "2. A working conversation about the code you already have." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "3. A first slice in your repository, so both of us can see the fit." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "4. Then the rest of the build, or a clean stop if it is the wrong job." })
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "md:col-span-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "border-t border-line",
				children: roles.map((role) => {
					const expanded = open === role.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-b border-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full min-h-16 items-start justify-between gap-4 py-5 text-left",
							"aria-expanded": expanded,
							onClick: () => setOpen(expanded ? "" : role.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-serif text-2xl",
								children: role.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 block text-sm text-muted",
								children: [
									role.team,
									" · ",
									role.location,
									" · ",
									role.type
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pt-1 text-muted",
								"aria-hidden": true,
								children: expanded ? "–" : "+"
							})]
						}), expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pb-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "max-w-2xl text-sm leading-relaxed text-ink",
									children: role.summary
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-4 space-y-2",
									children: role.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "text-sm text-muted",
										children: point
									}, point))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => copyRole(role.title, role.id),
									className: cn("mt-5 min-h-11 border border-ink px-4 text-sm", copied === role.id ? "bg-accent text-paper border-accent" : "hover:bg-ink hover:text-paper"),
									children: copied === role.id ? "Note copied" : "Copy a hiring note"
								}),
								copied === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted",
									children: "Copy failed. Write to hello@jprashidul.dev with the kind of work in the subject."
								}) : null
							]
						}) : null]
					}, role.id);
				})
			})
		})]
	})] });
}
//#endregion
export { CareersPage as component };
