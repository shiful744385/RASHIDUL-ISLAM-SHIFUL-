//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DLPHzAjX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/journal",
			"/work",
			"/about",
			"/careers",
			"/contact",
			"/open-source",
			"/principles",
			"/services"
		],
		preloads: [
			"/assets/index-BcrdUqef.js",
			"/assets/useSelector-B_P3tCcN.js",
			"/assets/preload-helper-DzSLnF-D.js",
			"/assets/button-DFOos8I4.js",
			"/assets/site-chrome-BL4E-PGs.js",
			"/assets/root-DLTE-HSj.js",
			"/assets/matchContext-DjqYPQ37.js",
			"/assets/site-content-B8X3edfl.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BcrdUqef.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-67CeG3sJ.js"]
	},
	"/journal": {
		filePath: "/workspace/src/routes/journal/route.tsx",
		children: ["/journal/$slug", "/journal/"],
		preloads: ["/assets/route-BH06ahcM.js"]
	},
	"/work": {
		filePath: "/workspace/src/routes/work/route.tsx",
		children: ["/work/$slug", "/work/"],
		preloads: ["/assets/route-BaDKQTX9.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DMa-mCm7.js"]
	},
	"/careers": {
		filePath: "/workspace/src/routes/careers.tsx",
		children: void 0,
		preloads: ["/assets/careers-B6_8LFx3.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-DFFfXU6U.js"]
	},
	"/open-source": {
		filePath: "/workspace/src/routes/open-source.tsx",
		children: void 0,
		preloads: ["/assets/open-source-BP8M8Ocl.js"]
	},
	"/principles": {
		filePath: "/workspace/src/routes/principles.tsx",
		children: void 0,
		preloads: ["/assets/principles-C5QEFi5E.js"]
	},
	"/services": {
		filePath: "/workspace/src/routes/services.tsx",
		children: void 0,
		preloads: ["/assets/services-B4DHzpDG.js"]
	},
	"/journal/$slug": {
		filePath: "/workspace/src/routes/journal/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-RSrSJmjD.js"]
	},
	"/work/$slug": {
		filePath: "/workspace/src/routes/work/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-CVRTfHgq.js"]
	},
	"/journal/": {
		filePath: "/workspace/src/routes/journal/index.tsx",
		children: void 0,
		preloads: ["/assets/journal-h9I0mJ7U.js"]
	},
	"/work/": {
		filePath: "/workspace/src/routes/work/index.tsx",
		children: void 0,
		preloads: ["/assets/work-C20Hlaek.js"]
	}
} });
//#endregion
export { tsrStartManifest };
