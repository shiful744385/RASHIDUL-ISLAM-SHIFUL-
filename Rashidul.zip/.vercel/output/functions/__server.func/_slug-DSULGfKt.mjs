import { J as require_jsx_runtime, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { h as buttonStyles, r as getArticle, t as articles } from "./_ssr/site-content-BmDfEnfW.mjs";
import { a as Prose, r as Route$2 } from "./_ssr/router-DTCHPS2r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-DSULGfKt.js
var import_jsx_runtime = require_jsx_runtime();
function ArticlePage() {
	const { slug } = Route$2.useParams();
	const article = getArticle(slug);
	if (!article) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-5 py-24 md:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-serif text-4xl",
			children: "That note is not here."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/journal",
			className: buttonStyles({
				variant: "quiet",
				className: "mt-6"
			}),
			children: "Back to the notes"
		})]
	});
	const more = articles.filter((item) => item.slug !== article.slug).slice(0, 2);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "border-b border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-5 py-16 md:px-8 md:py-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-widest text-accent",
					children: article.kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-serif text-4xl leading-tight md:text-6xl",
					children: article.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-lg leading-relaxed text-muted",
					children: article.dek
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-8 text-sm text-muted",
					children: [
						article.author,
						", ",
						article.role,
						" · ",
						article.date,
						" · ",
						article.minutes,
						" min read"
					]
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-3xl px-5 py-12 md:px-8 md:py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { paragraphs: article.paragraphs })
	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-14 md:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-muted",
				children: "Continue"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 grid gap-6 md:grid-cols-2",
				children: more.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/journal/$slug",
					params: { slug: item.slug },
					className: "font-serif text-2xl hover:text-accent",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: item.dek
				})] }, item.slug))
			})]
		})
	})] });
}
//#endregion
export { ArticlePage as component };
